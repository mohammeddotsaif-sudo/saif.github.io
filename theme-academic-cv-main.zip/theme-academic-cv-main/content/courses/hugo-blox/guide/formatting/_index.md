---
title: Formatting
---

Write rich, engaging content with Markdown and re-usable Hugo Blox components (shortcodes):

{{< cards >}}
  {{< card url="button" title="Button" icon="cursor-arrow-rays" >}}
  {{< card url="callout" title="Callout" icon="warning" >}}
  {{< card url="cards" title="Cards" icon="card" >}}
  {{< card url="toggle" title="Spoiler" icon="chevron-right" >}}
  {{< card url="steps" title="Steps" icon="one" >}}
{{< /cards >}}
