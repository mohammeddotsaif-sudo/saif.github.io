---
title: Spoilers
---

A Hugo shortcode to toggle collapsible content.

<!--more-->

## Example

{{< spoiler text="Click to view the spoiler" >}}
You found me!

Markdown is **supported**.
{{< /spoiler >}}

## Usage

````
{{</* spoiler text="Click to view the spoiler" */>}}

This is the content of the details.

Markdown is **supported**.

{{</* /spoiler */>}}
````
