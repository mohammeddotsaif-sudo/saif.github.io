---
title: PyTorch
date: 2023-10-26
links:
  - type: site
    url: https://github.com/pytorch/pytorch
tags:
  - Hugo
  - HugoBlox
  - Markdown
---

PyTorch is a Python package that provides tensor computation (like NumPy) with strong GPU acceleration.

<!--more-->
